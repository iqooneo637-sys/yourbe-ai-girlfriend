import React, { useState } from 'react';
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import * as Speech from 'expo-speech';
import { StatusBar } from 'expo-status-bar';
import { CHAT_API_URL, GIRLFRIEND_NAME } from './src/config';

const welcome = {
  id: 'welcome',
  role: 'assistant',
  content: 'Hii jaanu! ❤️ Main Yourbe hoon. Aaj tumhara din kaisa raha?'
};

export default function App() {
  const [messages, setMessages] = useState([welcome]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);

  async function sendMessage() {
    const text = input.trim();
    if (!text || busy) return;
    const userMessage = { id: String(Date.now()), role: 'user', content: text };
    const updated = [...messages, userMessage];
    setMessages(updated);
    setInput('');
    setBusy(true);

    try {
      if (CHAT_API_URL.includes('YOUR-BACKEND')) {
        throw new Error('Backend URL abhi configure nahi hua. README follow karke backend URL add karo.');
      }
      const response = await fetch(CHAT_API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: `You are ${GIRLFRIEND_NAME}, a fictional AI companion. Be warm, caring, respectful and naturally romantic. Speak in Hinglish (Hindi + English in Roman script). You are an AI, never claim to be a real human. Respect boundaries and never pressure the user.` },
            ...updated.filter(m => m.id !== 'welcome').map(m => ({ role: m.role, content: m.content }))
          ]
        })
      });
      if (!response.ok) throw new Error(`Server error (${response.status})`);
      const data = await response.json();
      if (!data.reply) throw new Error('Backend response must contain a "reply" field.');
      const reply = { id: String(Date.now() + 1), role: 'assistant', content: data.reply };
      setMessages(prev => [...prev, reply]);
      Speech.speak(data.reply, { language: 'hi-IN', rate: 0.94, pitch: 1.08 });
    } catch (err) {
      setMessages(prev => [...prev, { id: String(Date.now() + 2), role: 'assistant', content: `Oops ❤️ ${err.message}` }]);
    } finally {
      setBusy(false);
    }
  }

  function speakAgain(text) {
    Speech.stop();
    Speech.speak(text, { language: 'hi-IN', rate: 0.94, pitch: 1.08 });
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <View style={styles.header}>
        <View style={styles.avatar}><Text style={styles.avatarText}>Y</Text></View>
        <View><Text style={styles.title}>Yourbe ❤️</Text><Text style={styles.subtitle}>AI girlfriend · Hinglish · Online</Text></View>
        <View style={styles.online}><Text style={styles.onlineText}>● Online</Text></View>
      </View>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <FlatList
          style={styles.list}
          contentContainerStyle={styles.messages}
          data={messages}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <View style={[styles.bubble, item.role === 'user' ? styles.userBubble : styles.botBubble]}>
              <Text style={[styles.message, item.role === 'user' ? styles.userText : styles.botText]}>{item.content}</Text>
              {item.role === 'assistant' && item.id !== 'welcome' && (
                <TouchableOpacity onPress={() => speakAgain(item.content)}><Text style={styles.speak}>🔊 Listen</Text></TouchableOpacity>
              )}
            </View>
          )}
        />
        {busy && <View style={styles.typing}><ActivityIndicator color="#d94d83" /><Text style={styles.typingText}>Yourbe is typing...</Text></View>}
        <View style={styles.composer}>
          <TextInput value={input} onChangeText={setInput} placeholder="Yourbe ko message bhejo..." placeholderTextColor="#9b8790" style={styles.input} multiline />
          <TouchableOpacity style={styles.send} onPress={sendMessage} disabled={busy}><Text style={styles.sendText}>➤</Text></TouchableOpacity>
        </View>
        <Text style={styles.disclaimer}>Yourbe is an AI companion, not a real person.</Text>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#fff7fa' },
  flex: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: 16, backgroundColor: '#ffe6ef', borderBottomWidth: 1, borderBottomColor: '#f7c9d9' },
  avatar: { width: 46, height: 46, borderRadius: 23, backgroundColor: '#d94d83', alignItems: 'center', justifyContent: 'center', marginRight: 11 },
  avatarText: { color: 'white', fontSize: 22, fontWeight: 'bold' },
  title: { fontSize: 20, fontWeight: 'bold', color: '#7c2349' },
  subtitle: { fontSize: 12, color: '#9a5572', marginTop: 2 },
  online: { marginLeft: 'auto' },
  onlineText: { color: '#278451', fontSize: 12, fontWeight: '600' },
  list: { flex: 1 },
  messages: { padding: 14, gap: 10 },
  bubble: { maxWidth: '84%', borderRadius: 18, padding: 12 },
  userBubble: { alignSelf: 'flex-end', backgroundColor: '#d94d83', borderBottomRightRadius: 5 },
  botBubble: { alignSelf: 'flex-start', backgroundColor: 'white', borderBottomLeftRadius: 5, borderWidth: 1, borderColor: '#f5dbe5' },
  message: { fontSize: 15, lineHeight: 21 },
  userText: { color: 'white' },
  botText: { color: '#512d3d' },
  speak: { color: '#b6376c', fontSize: 12, marginTop: 8, fontWeight: '600' },
  typing: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 18, paddingBottom: 8 },
  typingText: { color: '#9a5572', fontSize: 12 },
  composer: { flexDirection: 'row', alignItems: 'center', padding: 10, gap: 8, backgroundColor: 'white', borderTopWidth: 1, borderColor: '#f3dce5' },
  input: { flex: 1, maxHeight: 100, minHeight: 44, backgroundColor: '#fff5f8', borderRadius: 22, paddingHorizontal: 16, paddingVertical: 10, color: '#512d3d' },
  send: { width: 46, height: 46, borderRadius: 23, backgroundColor: '#d94d83', alignItems: 'center', justifyContent: 'center' },
  sendText: { color: 'white', fontSize: 22, fontWeight: 'bold' },
  disclaimer: { textAlign: 'center', color: '#a48c96', fontSize: 10, paddingBottom: 5, backgroundColor: 'white' }
});
