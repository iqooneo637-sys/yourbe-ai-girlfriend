# Yourbe AI Girlfriend — Android starter

This is an Expo / React Native starter designed to be edited from an Android phone and built in the cloud.

## What is included
- Hinglish romantic/caring chat UI
- Text chat connected to your own backend endpoint
- Voice input using the phone's speech recognition capability (optional; requires a compatible Expo development build)
- Text-to-speech using Android's installed speech engine
- No API key is stored in the app

## Important
This starter does **not** include an AI API key or a working hosted backend. You must deploy a small backend and put its HTTPS URL in `src/config.js`. Never put a private AI API key in the mobile app.

## Phone-only workflow
1. Create a free Expo account at https://expo.dev/.
2. Upload this project to a GitHub repository (GitHub mobile website/app can do this, or use an online editor such as github.dev).
3. Open https://expo.dev/eas and follow the EAS setup instructions.
4. From a cloud development environment / terminal, run:
   - `npm install`
   - `npx eas-cli login`
   - `npx eas-cli build:configure`
   - `npx eas-cli build --platform android --profile preview`
5. EAS will build an installable Android APK for the preview profile. Download it from the build page.

A terminal is needed for the EAS commands. On an Android-only setup, use a browser-based cloud IDE with terminal support. The Expo Go app alone cannot produce an APK.

## Configure the backend
Edit `src/config.js` and set `CHAT_API_URL` to your deployed HTTPS endpoint. The endpoint should accept:
`POST { "messages": [{ "role": "system"|"user"|"assistant", "content": "..." }] }`
and return:
`{ "reply": "..." }`

Your backend should authenticate requests, apply rate limits, and call your AI provider using a secret stored server-side.

## Voice
- Android text-to-speech is available through `expo-speech`.
- Speech recognition is marked as optional because native speech-recognition support may require an Expo development build and additional configuration. The chat works without it.

## Build output
EAS build page provides the APK download link. Keep API credentials on the backend only.

## Backend starter
The `server/` folder contains a small Node.js API proxy for providers that expose an OpenAI-compatible Chat Completions endpoint. Deploy it to a trusted Node hosting service, set `AI_API_KEY`, `AI_MODEL`, and `AI_CHAT_COMPLETIONS_URL` as server environment variables, then set `CHAT_API_URL` in `src/config.js` to `https://your-host/chat`. Check your provider's current API pricing and usage limits before adding a payment method. Add authentication and stricter rate limiting before sharing the app publicly; the included sample is a learning starter, not production-hardened.
