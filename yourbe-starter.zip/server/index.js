import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();
const app = express();
app.use(cors({ origin: process.env.APP_ORIGIN || '*' }));
app.use(express.json({ limit: '20kb' }));

app.get('/health', (_req, res) => res.json({ ok: true }));

app.post('/chat', async (req, res) => {
  try {
    const apiKey = process.env.AI_API_KEY;
    const model = process.env.AI_MODEL;
    const apiUrl = process.env.AI_CHAT_COMPLETIONS_URL;
    if (!apiKey || !model || !apiUrl) {
      return res.status(503).json({ error: 'Backend AI settings are not configured.' });
    }

    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    if (!messages.length || messages.length > 30) {
      return res.status(400).json({ error: 'Send between 1 and 30 chat messages.' });
    }

    const safeMessages = messages
      .filter(m => ['system', 'user', 'assistant'].includes(m.role) && typeof m.content === 'string')
      .map(m => ({ role: m.role, content: m.content.slice(0, 4000) }));

    const upstream = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ model, messages: safeMessages, temperature: 0.85, max_tokens: 350 })
    });

    const data = await upstream.json();
    if (!upstream.ok) {
      console.error('AI provider error:', upstream.status, data);
      return res.status(502).json({ error: 'AI provider request failed.' });
    }
    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== 'string' || !reply.trim()) {
      return res.status(502).json({ error: 'AI provider returned no text.' });
    }
    res.json({ reply: reply.trim() });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Unexpected server error.' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Yourbe backend listening on ${port}`));
