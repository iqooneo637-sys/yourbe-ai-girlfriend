// Replace this with your deployed HTTPS backend endpoint.
// Do not put an AI provider secret/API key in this file.
export const CHAT_API_URL = "https://YOUR-BACKEND.example.com/chat";
export const GIRLFRIEND_NAME = "Yourbe";
